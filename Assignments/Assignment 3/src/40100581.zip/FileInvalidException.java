import java.io.FileNotFoundException;

public class FileInvalidException extends FileNotFoundException {
    private static String defaultError = "Error: Input file cannot be parsed due to missing information (i.e. month={}, title={}, etc.)";

    public FileInvalidException() {
        super(defaultError);
    }

    public void fileDoesNotExist(){
        System.out.println("-----------DNE-----------");
    }
    //
}
