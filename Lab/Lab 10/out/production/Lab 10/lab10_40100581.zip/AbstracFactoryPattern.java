public class AbstracFactoryPattern implements AppleJuice, OrangeJuice{
    public void makeJuices (JuiceFactory factory){
        /**
         * I dont know what you want me to do here. Mike (the TA) was not online for the lab so I couldnt ask him any
         * questions.
         */


        JuiceFactory[] array = new JuiceFactory[5];

        array[0] = factory;

        for (int i = 0; i < 5; i++){
            //
        }
    }

    @Override
    public void getAppleJuiceInfo() {

    }

    @Override
    public void getOrangeJuiceInfo() {

    }
}
