/**
 * Faizan Ahmad (40100581)
 */

public class Driver {
    public static void main(String args[]){

        AbstracFactoryPattern abstracFactoryPattern;

        JuiceFactory juiceFactory = new DelMonte();
    }
}
