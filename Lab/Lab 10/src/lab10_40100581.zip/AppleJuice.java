public interface AppleJuice {
    public void getAppleJuiceInfo();
}
