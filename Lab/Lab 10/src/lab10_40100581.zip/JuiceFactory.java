public interface JuiceFactory {
    AppleJuice createAppleJuice();
    OrangeJuice createOrangeJuice();
}
