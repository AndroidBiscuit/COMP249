public interface OrangeJuice {
    public void getOrangeJuiceInfo();
}
