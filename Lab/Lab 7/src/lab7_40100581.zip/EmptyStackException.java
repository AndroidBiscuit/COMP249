public class EmptyStackException extends Exception {
    public EmptyStackException(String mess){
        System.out.println(mess);
    }
}
