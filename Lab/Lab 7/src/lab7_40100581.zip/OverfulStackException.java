public class OverfulStackException extends Exception {
    public OverfulStackException(String mess){
        System.out.println(mess);
    }
}
